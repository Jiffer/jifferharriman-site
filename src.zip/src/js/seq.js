/* Hero sequencer — 16 steps, click to toggle, plays a pentatonic run.
   Audio only starts on a user gesture (browser rule, and it's politer). */

(function () {
  const el = document.querySelector('[data-seq]');
  if (!el) return;

  const STEPS = 16;
  const TEMPO_MS = 260;

  // Pentatonic across three octaves — any pattern sounds intentional.
  const SCALE = [
    130.81, 146.83, 164.81, 196.00, 220.00, 261.63, 293.66, 329.63,
    392.00, 440.00, 523.25, 587.33, 659.25, 783.99, 880.00, 1046.50
  ];

  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const pattern = new Array(STEPS).fill(false);
  [0, 3, 5, 6, 10, 11, 14].forEach(i => pattern[i] = true);

  let head = 0;
  let timer = null;
  let audio = null;
  let sound = false;

  // --- build cells ---
  const cells = [];
  for (let i = 0; i < STEPS; i++) {
    const b = document.createElement('button');
    b.className = 'seq__cell';
    b.type = 'button';
    b.setAttribute('role', 'switch');
    b.setAttribute('aria-checked', pattern[i]);
    b.setAttribute('aria-label', `Step ${i + 1}`);
    b.addEventListener('click', () => {
      pattern[i] = !pattern[i];
      b.setAttribute('aria-checked', pattern[i]);
      b.classList.toggle('seq__cell--on', pattern[i]);
      enableSound();                    // first click unlocks audio
      if (pattern[i]) play(SCALE[i]);   // audition the step you just set
    });
    if (pattern[i]) b.classList.add('seq__cell--on');
    el.append(b);
    cells.push(b);
  }

  // --- transport ---
  const bar = document.querySelector('[data-seq-controls]');
  const playBtn = bar && bar.querySelector('[data-seq-play]');
  const muteBtn = bar && bar.querySelector('[data-seq-mute]');

  if (playBtn) {
    playBtn.addEventListener('click', () => (timer ? stop() : start()));
  }
  if (muteBtn) {
    muteBtn.addEventListener('click', () => {
      sound ? (sound = false) : enableSound();
      muteBtn.setAttribute('aria-pressed', sound);
      muteBtn.textContent = sound ? 'Sound on' : 'Sound off';
    });
  }

  function start() {
    if (timer) return;
    timer = setInterval(tick, TEMPO_MS);
    if (playBtn) { playBtn.textContent = 'Pause'; playBtn.setAttribute('aria-pressed', 'true'); }
  }

  function stop() {
    clearInterval(timer);
    timer = null;
    cells.forEach(c => c.classList.remove('seq__cell--head'));
    if (playBtn) { playBtn.textContent = 'Play'; playBtn.setAttribute('aria-pressed', 'false'); }
  }

  function tick() {
    cells[head].classList.remove('seq__cell--head');
    head = (head + 1) % STEPS;
    cells[head].classList.add('seq__cell--head');
    if (pattern[head]) {
      cells[head].classList.add('seq__cell--hit');
      setTimeout(() => cells[head].classList.remove('seq__cell--hit'), 120);
      play(SCALE[head]);
    }
  }

  // --- audio ---
  function enableSound() {
    if (!audio) {
      const Ctx = window.AudioContext || window.webkitAudioContext;
      if (!Ctx) return;
      audio = new Ctx();
    }
    if (audio.state === 'suspended') audio.resume();
    sound = true;
    if (muteBtn) { muteBtn.setAttribute('aria-pressed', 'true'); muteBtn.textContent = 'Sound on'; }
  }

  function play(freq) {
    if (!sound || !audio) return;
    const t = audio.currentTime;
    const osc = audio.createOscillator();
    const gain = audio.createGain();
    osc.type = 'triangle';
    osc.frequency.value = freq;
    gain.gain.setValueAtTime(0.0001, t);
    gain.gain.exponentialRampToValueAtTime(0.14, t + 0.008);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.45);
    osc.connect(gain).connect(audio.destination);
    osc.start(t);
    osc.stop(t + 0.5);
  }

  if (!reduced) start();
})();
