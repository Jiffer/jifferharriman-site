---
title: Solarophone
year: 2016
tagline: Sound art in the conoid, played by light.
kinds: [installation, public, commission]
role: Concept, hardware, software
venues:
  - Boulder Public Library, Mar – Jun 2016
---

An interactive sound installation sited in the conoid at Boulder Public Library's
main branch, on view March through June 2016.
