---
title: Galaga's Ghost
year: 2021
tagline: A six-player musical arcade machine, and a dance party waiting to happen.
kinds: [installation, instrument, collaboration, public]
role: Concept, hardware, software
credits: Sean Winters, Chase Stewart, Spencer Arrasmith, Eric Atencio, Torin Hopkins, Marc Seyfirth
venues:
  - Museum of Boulder, Oct 2021 – Jan 2022
booking: true
---

Galaga's Ghost is a six-player musical arcade cabinet built for *Convivial Machines*
at the Museum of Boulder. Six people play at once; nobody has to know how to play anything.

Built in collaboration with Boulder Experiments in Art and Technology (B.E.A.T.).
